<!DOCTYPE html>
<html lang="es">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="{{ url('/srclp/tailwind.css') }}">
    <title>Conéctate!</title>
</head>

<body class="font-sans bg-white text-gray-900">

  <main class="w-full">

    <!-- start header -->
    <header class="w-full bg-transparent fixed top-0 left-0 z-50 px-4 sm:px-8 lg:px-16 xl:px-40 2xl:px-64 py-6 xl:py-8" id="navbar">
      <nav class="flex items-center justify-between">
        <div class="">
          <a href="{{ url('/') }}">
            <img src="{{ url('/srclp/logoconletras.png') }}" alt="">
          </a>
        </div>

        <div class="block sm:hidden">
          <button type="button" class="navbar-toggler">
            <span class="navbar-toggler-bar"></span>
            <span class="navbar-toggler-bar"></span>
            <span class="navbar-toggler-bar"></span>
          </button>
        </div>

        <div class="hidden sm:flex">
          <ul class="flex flex-col sm:flex-row">
            <li><a href="{{ url('/dashboard') }}" class="sm:px-4 py-2 block">Cursos </a></li>
            <li><a href="https://classroom.google.com/" class="sm:px-4 py-2 sm:hidden lg:block">Classroom</a></li>
            <li><a href="#" class="sm:px-4 py-2 sm:hidden md:block">Ayuda</a></li>
            <li><a href="#" class="sm:px-4 py-2 sm:hidden md:block">otros</a></li>
          
        
          
          @if (Route::has('login'))
            
                @auth
                    <a href="{{ url('/dashboard') }}" class="sm:px-4 py-2 block bg-blue-600 text-white rounded-lg ml-4">Ir a mi perfil</a>
                @else
                    <a href="{{ route('login') }}"  class="sm:px-4 py-2 block bg-blue-600 text-white rounded-lg ml-4">Iniciar Sesión</a>

                    
                @endif
            
        @endif
      </ul>
        </div>
      </nav>
    </header>
    <!-- end header -->

    <!-- start hero section -->
    <section class="relative bg-blue-100 px-4 sm:px-8 lg:px-16 xl:px-40 2xl:px-64 pt-32 pb-48 sm:pb-64 md:pt-40 md:pb-48 lg:pt-40 xl:pb-64 2xl:pt-56 2xl:pb-96 text-center sm:text-left">
      <div>
        <div class="relative w-full sm:w-2/3 lg:w-1/2 z-10">
          <h1 class="text-3xl lg:text-4xl xl:text-5xl leading-tight font-bold">Bienvenidos al portal educativo <br> Estamos trabajando, para iniciar lo mas pronto posible    </h1>
          <p class="text-base leading-snug text-gray-700 mt-4">Espacio virtual donde encontraras material académio selecto y herramientas innovadoras que te ayudaran a cumplir co tus objetivos, utiliza al máximo esta nueva experiencia de aprendizaje, navega y aprende. Esta iniciativa se irá fortaleciéndose a medida que se nutra con más contenidos.</p>
          <a href="/#" class="w-full block sm:inline-block sm:w-auto px-6 py-4 bg-blue-600 text-white rounded-lg mt-8"> 
            Podrás ingresar tu código cuando estemos listos!!
          </a>
        </div>

        <div class="w-full absolute bottom-0 right-0">
        <img src="srclp/banner.png">
        </div>
      </div>
    </section>
    <!-- end hero section -->

    <!-- start how it works -->
    <section class="relative bg-gray-100 px-4 sm:px-8 lg:px-16 xl:px-40 2xl:px-64 py-20 text-center">
      <div>
        <h2 class="text-3xl leading-tight font-bold">¿Qué quieres aprender?</h2>
      </div>

      <div class="flex flex-col md:flex-row items-start justify-between mt-12">
        <div class="w-full bg-white shadow-lg rounded-lg px-4 py-6 lg:p-8 md:mx-2 lg:mx-4">
          <img src="srclp/INFO.png" alt="" class="mx-auto h-32">
          <h4 class="text-xl font-bold leading-tight mt-8">Informatica y computación</h4>
          <p class="text-gray-700 mt-2">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
        </div>

        <div class="w-full bg-white shadow-lg rounded-lg px-4 py-6 lg:p-8 md:mx-2 lg:mx-4 mt-4 md:mt-0">
          <img src="srclp/QUIMICA.png" alt="" class="mx-auto h-32">
          <h4 class="text-xl font-bold leading-tight mt-8">Química</h4>
          <p class="text-gray-700 mt-2">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
        </div>

        <div class="w-full bg-white shadow-lg rounded-lg px-4 py-6 lg:p-8 md:mx-2 lg:mx-4 mt-4 md:mt-0">
          <img src="srclp/TECNO.png" alt="" class="mx-auto h-32">
          <h4 class="text-xl font-bold leading-tight mt-8">Tecnología</h4>
          <p class="text-gray-700 mt-2">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
        </div>
      </div>

      <div class="mt-12 md:mt-20 w-full md:max-w-3xl mx-auto">
        <p class="text-xl">NAVEGA Y APRENDE!
      </div>
    </section>
    <!-- end how it works -->


    <!-- start footer -->
    <footer class="relative bg-white px-4 sm:px-8 lg:px-16 xl:px-40 2xl:px-64 pt-12 pb-10 text-center sm:text-left">
      <div class="flex flex-col sm:flex-row sm:flex-wrap">
        <div class="sm:w-1/2 lg:w-1/5">
          <h6 class="text-sm text-gray-600 font-bold uppercase">Portal Educativo</h6>
          <ul class="mt-4">
            <li><a href="/#">Otros recursos</a></li>
            <li class="mt-2"><a href="#">Comentarios</a></li>
          </ul>
        </div>

        <div class="mt-8 sm:w-1/2 sm:mt-12 lg:w-1/5 lg:mt-0">
          <h6 class="text-sm text-gray-600 font-bold uppercase">Contactos Computación</h6>
          <ul class="mt-4">
            <li><a href="#">orosco.alejandro@ffroebel.com</a></li>
            <li class="mt-2"><a href="#">70351968</a></li>
          </ul>
        </div>

        <div class="mt-8 sm:w-1/2 sm:mt-12 lg:w-1/5 lg:mt-0">
          <h6 class="text-sm text-gray-600 font-bold uppercase">Contactos Quimica - Tecnología</h6>
          <ul class="mt-4">
            <li><a href="#">s.barcaya@ffroebel.com</a></li>
            <li class="mt-2"><a href="#">60761760</a></li>
          </ul>
        </div>

        <div class="mt-12 sm:w-1/2 lg:w-2/5 lg:mt-0 lg:pl-12">
          <div>
            <img src="{{ url('/srclp/logoconletras.png') }}" alt="">
          </div>

          <p class="text-base text-gray-600 mt-4">una plataforma pensada para apoyar el proceso aprendizaje.</p>
        </div>
      </div>

      <div class="mt-16">
        <hr class="mb-8">
        <p class="text-sm text-gray-600">2022 © conectate.life.</p>
      </div>
    </footer>
    <!-- end footer -->

  </main>

  <script type="text/javascript" async="" src="srclp/analytics.js.descarga"></script><script src="srclp/jquery-3.4.1.min.js.descarga" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>

  <script>
    $('.navbar-toggler').click(function () {
      $(this).toggleClass('active');
      $('.navigation-menu').toggleClass('hidden');
      $('#navbar').addClass('bg-white');
    });

    $(function () {
      var navigation = $("#navbar");

      $(window).scroll(function () {
        var scroll = $(window).scrollTop();
        if (scroll >= 10) {
          navigation.addClass("bg-white xl:py-4 shadow-md");
          navigation.removeClass("xl:py-8");
        } else {
          navigation.removeClass("bg-white xl:py-4 shadow-md");
          navigation.addClass("xl:py-8");
        }
      });
    });
  </script>

  <!-- Global site tag (gtag.js) - Google Analytics -->
  <script async="" src="srclp/js"></script>
  <script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
      dataLayer.push(arguments);
    }
    gtag('js', new Date());

    gtag('config', 'UA-131505823-2');
  </script>




</body></html>