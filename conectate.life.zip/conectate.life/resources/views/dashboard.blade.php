<x-app-layout title="Dashboard">
    <div class="container grid px-6 mx-auto">
        <h2 class="my-6 text-2xl font-semibold text-gray-700 dark:text-gray-200">
            Mi perfil:
        </h2>

        <!-- Cards -->
        <div class="grid gap-6 mb-8 md:grid-cols-2 xl:grid-cols-4">
            <!-- Card -->
            @foreach ($courses as $course)
            
        
            <div class="flex items-center p-4 bg-white rounded-lg shadow-xs dark:bg-gray-800">
                
                    
                
                <div>
                    <p class="mb-2 text-sm font-medium text-gray-600 dark:text-gray-400">
                        <img src="{{ $course->img  }}" alt=""><br>
                        {{ $course->name  }}
                    </p>
                    <p class="text-lg font-semibold text-gray-700 dark:text-gray-200">
                        {{ $course->description  }}
                    </p>
                </div>
            </div>
            @endforeach
            <!-- Card -->
            
        </div>

    
    </div>

    {{-- <div class="py-12">
        <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">
            <div class="overflow-hidden bg-white shadow-xl sm:rounded-lg">
                <x-jet-welcome />
            </div>
        </div>
    </div> --}}
</x-app-layout>