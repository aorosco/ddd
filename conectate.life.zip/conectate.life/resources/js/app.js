require('./bootstrap');

import 'alpinejs'
