<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

class InscriptionFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'user_id'   => rand(1,10),
            'course_id' => rand(1,6),
            //'name'          => $this->faker->numerify('inscripcion   ####') ,
            'code'      => $this->faker->bothify('cod####???')
        ];
    }
}
