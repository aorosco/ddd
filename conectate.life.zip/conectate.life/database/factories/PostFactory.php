<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

class PostFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'course_id'     => rand(1,6),
            'name'          => $this->faker->numerify('Post   ####') ,
            //'active'        => true,
            'description'   =>$this->faker->text($maxNbChars = 200) ,
            'img'           => $this->faker->imageUrl($width = 640, $height = 480),
            'group_id'      => rand(1,7),
            'type'          =>$this->faker->fileExtension , 
            'src'           => "/direccion/asdf",
            'order'         =>rand(1,10)
        ];
    }
}
