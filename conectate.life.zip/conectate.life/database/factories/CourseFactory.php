<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

class CourseFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'category_id'   => $this->faker->numberBetween(1,4),
            'name'          => $this->faker->numerify('curso   ####') ,
            'slug'          => $this->faker->slug ,
            'img'           => $this->faker->imageUrl($width = 640, $height = 480),
            'description'   => $this->faker->text($maxNbChars = 200),
            'active'        => $this->faker->boolean,
            'order'         => $this->faker->numberBetween(1,20),
        ];
    }
}
