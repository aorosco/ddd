<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use App\Models\Category;
use App\Models\Group;
use App\Models\Course;
use App\Models\Inscription;
use App\Models\Post;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        User::factory(10)->create();
        Category::factory(4)->create();
        Group::factory(7)->create();
        Course::factory(6)->create();
        Inscription::factory(10)->create();
        Post::factory(50)->create();

        



    }
}
