<?php return array (
  'course-list' => 'App\\Http\\Livewire\\CourseList',
);