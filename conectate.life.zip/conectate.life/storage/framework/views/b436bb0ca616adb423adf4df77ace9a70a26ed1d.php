<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'px-4 py-2 text-sm font-medium leading-5 text-white transition-colors duration-150 bg-purple-600 border border-transparent rounded-lg active:bg-purple-600 hover:bg-purple-700 focus:outline-none focus:shadow-outline-purple'])); ?>>
    <?php echo e($slot); ?>

</button><?php /**PATH C:\xampp2\htdocs\larawind\resources\views/components/button.blade.php ENDPATH**/ ?>