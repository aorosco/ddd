<!-- Desktop sidebar -->
<aside class="z-20 flex-shrink-0 hidden w-64 overflow-y-auto bg-white dark:bg-gray-800 md:block">
    <?php echo $__env->make('layouts._menus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</aside>
<?php /**PATH C:\xampp2\htdocs\larawind\resources\views/layouts/menu.blade.php ENDPATH**/ ?>